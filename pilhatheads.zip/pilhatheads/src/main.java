
import java.util.Stack;
public class main {

	public static void main (String args[]) throws InterruptedException {
		
		for (int i = 1; i <= 100; i++) {			
			new Pilha(i).start();
		}
		
	}
}
