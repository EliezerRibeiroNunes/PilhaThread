
import java.util.Stack;


public class Pilha extends Thread {

	private Integer num;
	
Stack<Integer> pilha = new Stack<>();
	
	public Pilha(Integer numero) {
		this.num = num;
	}
	
	public synchronized void empilhar() throws InterruptedException {
		wait();
		Stack<Integer> pilha = new Stack<>();
		for (int i = 1; i <= 10; i++) {			
			System.out.println(pilha);
		}		
	}
	
	@Override
	public void run() {
		System.out.println(this.getName());
		try {
			empilhar();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
